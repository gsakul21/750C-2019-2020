/**
 * \file main.h
 *
 * Contains common definitions and header files used throughout your PROS
 * project.
 *
 * Copyright (c) 2017-2019, Purdue University ACM SIGBots.
 * All rights reserved.
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/.
 */

#ifndef _PROS_MAIN_H_
#define _PROS_MAIN_H_

/**
 * If defined, some commonly used enums will have preprocessor macros which give
 * a shorter, more convenient naming pattern. If this isn't desired, simply
 * comment the following line out.
 *
 * For instance, E_CONTROLLER_MASTER has a shorter name: CONTROLLER_MASTER.
 * E_CONTROLLER_MASTER is pedantically correct within the PROS styleguide, but
 * not convienent for most student programmers.
 */
#define PROS_USE_SIMPLE_NAMES

/**
 * If defined, C++ literals will be available for use. All literals are in the
 * pros::literals namespace.
 *
 * For instance, you can do `4_mtr = 50` to set motor 4's target velocity to 50
 */
#define PROS_USE_LITERALS

#include "api.h"

/**
 * You should add more #includes here
 */
#include "okapi/api.hpp"
#include "pros/api_legacy.h"
#include "pros/apix.h"
/**
 * If you find doing pros::Motor() to be tedious and you'd prefer just to do
 * Motor, you can use the namespace with the following commented out line.
 *
 * IMPORTANT: Only the okapi or pros namespace may be used, not both
 * concurrently! The okapi namespace will export all symbols inside the pros
 * namespace.
 */
// using namespace pros;
// using namespace pros::literals;
// using namespace okapi;

/**
 * Prototypes for the competition control tasks are redefined here to ensure
 * that they can be called from user code (i.e. calling autonomous from a
 * button press in opcontrol() for testing purposes).
 */
#ifdef __cplusplus
extern "C" {
#endif
#define fULL_CIRCLE 935
#define f_T 665
#define twobarNum 720
#define height 360
#define tray 6040
#define iNTAKE_SPEED 150
#define sTACK_SPEED 125
#define constant 125
#define liftkP 0.1
#define liftkI 0.2
#define liftkD 0.1
#define medTowerPosition 3330
void autonomous(void);
void initialize(void);
void disabled(void);
void competition_initialize(void);
void opcontrol(void);
void drive(int x, int y);
void twobar(bool u, bool d);
void actuator(bool forward, bool back, bool slow);
void goofyintaker(bool open, bool close, bool left, bool right);
void flipout();
void macro();
//auton voids
void autonSelector(void);
void blueFrontAuton(void);
void blueBackAuton(void);
void redFrontAuton(void);
void redBackAuton(void);
int autonSelect = 0;
void boxIntakeA(bool direction, float speed, float time);
void moveFT(int dis, double speed);
void cw_turn(int angle, double speed);
void ccw_turn(int angle, double speed);
void DRFBS(double deg, double speed);
void traymover(double deg, double speed);
void twobarA(double deg, double speed);
void intakeA(std::string dir, double speed);

pros::Controller contrl(pros::E_CONTROLLER_MASTER);
pros::Motor motorFL(18);
pros::Motor motorBL(17);
pros::Motor motorFR(2);
pros::Motor motorBR(15);
pros::Motor twobarM(19);
pros::Motor intakeL(20);
pros::Motor intakeR(12);
pros::Motor actuatorM(11);
#ifdef __cplusplus
}
#endif

#ifdef __cplusplus
/**
 * You can add C++-only headers here
 */
//#include <iostream>
#endif

#endif  // _PROS_MAIN_H_
