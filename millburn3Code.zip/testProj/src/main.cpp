#include "main.h"
using namespace okapi;
bool toggle = false;
/**
 * A callback function for LLEMU's center button.
 *
 * When this callback is fired, it will toggle line 2 of the LCD text between
 * "I was pressed!" and nothing.
 */
void on_center_button() {
	static bool pressed = false;
	pressed = !pressed;
	if (pressed) {
		pros::lcd::set_text(2, "I was pressed!");
	} else {
		pros::lcd::clear_line(2);
	}
}
ControllerButton trayAdjuster(ControllerDigital::up, false);
ControllerButton towerMacro(ControllerDigital::down, false);
ControllerButton stackMacro(ControllerDigital::right, false);
ControllerButton driveToggle(ControllerDigital::Y, false);


/**
 * Runs initialization code. This occurs as soon as the program is started.
 *
 * All other competition modes are blocked by initialize; it is recommended
 * to keep execution time for this mode under a few seconds.
 */
bool side = false;
bool color = false;
//if color is false, blue alliance, if color is true, red alliance
//if side is false, back auton, if side is true, front auton
void initialize() {
	pros::lcd::initialize();
	pros::lcd::set_text(1, "Hello PROS User!");
	pros::lcd::register_btn1_cb(on_center_button);

	pros::lcd::clear_line(1);
	pros::lcd::set_text(1, "No auton currently selected.");


}

/**
 * Runs while the robot is in the disabled state of Field Management System or
 * the VEX Competition Switch, following either autonomous or opcontrol. When
 * the robot is enabled, this task will exit.
 */
void disabled() {}

/**
 * Runs after initialize(), and before autonomous when connected to the Field
 * Management System or the VEX Competition Switch. This is intended for
 * competition-specific initialization routines, such as an autonomous selector
 * on the LCD.
 *
 * This task will exit when the robot is enabled and autonomous or opcontrol
 * starts.
 */
 ADIButton switch1('G');
 ADIButton switch2('H');
 int alliance2 = 0;
 int autonSide2 = 0;
 int autonSelection = 0;
 //if color is false, blue alliance, if color is true, red alliance
 //if side is false, back auton, if side is true, front auton
void competition_initialize() {
	pros::lcd::initialize();
	pros::lcd::set_text(1, "Hello PROS User!");
	pros::lcd::register_btn1_cb(on_center_button);

	pros::lcd::clear_line(1);
	pros::lcd::set_text(1, "No auton currently selected.");

	while(true){
		pros::delay(100);
		if(switch2.isPressed() && switch1.isPressed()){
			pros::lcd::clear_line(3);
			pros::lcd::set_text(3, "Auton selection finalized.");
			break;
		}
		else if(switch2.isPressed()){
					autonSide2 += 1;
					pros::delay(100);
				}

		else if(switch1.isPressed()){
					alliance2 += 1;
					pros::delay(100);
				}

		if(alliance2 % 2 == 0){
			if(autonSide2 % 3 == 0){
				pros::lcd::clear_line(2);
				pros::lcd::set_text(2, "Blue Front Auton selected.");
				autonSelection = 1;
			}
			else if(autonSide2 % 3 == 1){
				pros::lcd::clear_line(2);
				pros::lcd::set_text(2, "Blue Back Auton selected.");
				autonSelection = 2;
			}
			else{
				pros::lcd::clear_line(2);
				pros::lcd::set_text(2, "Do Nothing selected.");
				autonSelection = 3;
			}
		}
		else{
			if(autonSide2 % 3 == 0){
				pros::lcd::clear_line(2);
				pros::lcd::set_text(2, "Red Front Auton selected.");
				autonSelection = 4;
			}
			else if(autonSide2 % 3 == 1){
				pros::lcd::clear_line(2);
				pros::lcd::set_text(2, "Red Back Auton selected.");
				autonSelect = 5;
			}
			else{
				pros::lcd::clear_line(2);
				pros::lcd::set_text(2, "Do Nothing selected.");
				autonSelection = 3;
			}
		}
		pros::delay(20);
	}
}



/**
 * Runs the user autonomous code. This function will be started in its own task
 * with the default priority and stack size whenever the robot is enabled via
 * the Field Management System or the VEX Competition Switch in the autonomous
 * mode. Alternatively, this function may be called in initialize or opcontrol
 * for non-competition testing purposes.
 *
 * If the robot is disabled or communications is lost, the autonomous task
 * will be stopped. Re-enabling the robot will restart the task, not re-start it
 * from where it left off.
 */
 auto myChassis = okapi::ChassisControllerBuilder()
 .withMotors({18,17},{-2,-15})
 .withDimensions(AbstractMotor::gearset::green, {{4.2_in, 10_in}, imev5GreenTPR})
 //.withGains({0.3,0.1,0.05},{0,0,0})
 .build();

 auto twoBar = okapi::AsyncPosControllerBuilder()
 .withMotor(19)
 .build();

 auto trayController = okapi::AsyncPosControllerBuilder()
 .withMotor(-11)
 .build();

 //if color is false, blue alliance, if color is true, red alliance
 //if side is false, back auton, if side is true, front auton
void autonomous() {
	switch(autonSelection){
		case 1:
				blueFrontAuton();
				break;
		case 2:
				blueBackAuton();
				break;
		case 3:
				break;
		case 4:
				redFrontAuton();
				break;
		case 5:
				redBackAuton();
				break;
	}
	//blueFrontAuton();
	//blueBackAuton();
	//redFrontAuton();
	//redBackAuton();
	//pranavsSpedAutonBlue();
}

void blueFrontAuton(){
	//Push preload towards row of 4
	//flipout
	intakeA("out", 200);
	//Make the starting position of the tray after the flipout the new 0, should help with the weird encoder values
	trayController->tarePosition();
	//end flipout
	pros::delay(1500);
	//start intaking
	intakeA("in", 200);

	//intake the stack
	myChassis->setMaxVelocity(45);
	myChassis->moveDistance(1.2206_m);
	myChassis->waitUntilSettled();
	intakeA("in", 0);
	//Drive back
	myChassis->setMaxVelocity(200);
	myChassis->moveDistance(-0.8206_m);
	myChassis->waitUntilSettled();
	//Turn towards the unprotected zone
	myChassis->setMaxVelocity(55);
	//Turn left
	myChassis->turnAngle(-135_deg);
	//Enter unprotected zone
	myChassis->setMaxVelocity(200);
	myChassis->moveDistance(0.3865_m);
	//Slow outake to adjust for extra intake
	intakeA("out", 150);
	pros::delay(540);
	intakeA("out", 0);
	//Move the tray forward
	trayController->setTarget(tray);
	//Delayed outake to help stack
	trayController->waitUntilSettled();
	intakeA("out", 145);
	//Stop outtake after certain time
	pros::delay(620);
	intakeA("out", 0);
	//Back up from the unprotected zone and move tray back down
	myChassis->moveDistance(-0.6_m);
	trayController->setTarget(-tray*0.75);
}

void redFrontAuton(){
	//Push preload towards row of 4
	//flipout
	intakeA("out", 200);
	//Make the starting position of the tray after the flipout the new 0, should help with the weird encoder values
	trayController->tarePosition();
	//end flipout
	pros::delay(2000);
	//start intaking
	intakeA("in", 200);

	//intake the stack
	myChassis->setMaxVelocity(75);
	myChassis->moveDistance(1.2206_m);
	myChassis->waitUntilSettled();
	intakeA("in", 0);
	//Drive back
	myChassis->setMaxVelocity(175);
	myChassis->moveDistance(-0.8206_m);
	myChassis->waitUntilSettled();
	//Turn towards the unprotected zone
	myChassis->setMaxVelocity(60);
	//Turn left
	myChassis->turnAngle(115_deg);
	//Enter unprotected zone
	myChassis->setMaxVelocity(200);
	myChassis->moveDistance(0.3875_m);
	myChassis->waitUntilSettled();
	//Slow outake to adjust for extra intake
	intakeA("out",120);
	pros::delay(540);
	intakeA("out", 0);
	//Move the tray forward
	trayController->setTarget(tray*0.95);
	//Delayed outake to help stack
	trayController->waitUntilSettled();
	intakeA("out", 85);
	//Stop outtake after certain time
	pros::delay(720);
	intakeA("out", 0);
	//Back up from the unprotected zone and move tray back down
	myChassis->moveDistance(-0.6_m);
	trayController->setTarget(-tray*0.75);
}

void blueBackAuton(){
	//flipout
	intakeA("out", 200);
	//Make the starting position of the tray after the flipout the new 0, should help with the weird encoder values
	trayController->tarePosition();
	//end flipout
	pros::delay(1000);
	//start intaking
	intakeA("in", 200);
	//intake the preload and the cube in front of it before the 4 stack
	myChassis->setMaxVelocity(100);
	myChassis->moveDistance(1.76_ft);
	myChassis->waitUntilSettled();
	//turn to the right
	myChassis->setMaxVelocity(55);
	myChassis->turnAngle(90_deg);
	//Get the third cube near the zone
	myChassis->setMaxVelocity(100);
	myChassis->moveDistance(1.7_ft);
	myChassis->waitUntilSettled();
	//Turn towards zone
	myChassis->setMaxVelocity(55);
	myChassis->turnAngle(45_deg);
	//Enter the zone
	myChassis->moveDistance(0.4_m);
	myChassis->waitUntilSettled();
	intakeA("out", 85);
	pros::delay(950);
	intakeA("out", 0);
	//Move the tray forward
	trayController->setTarget(tray*0.95);
	//Delayed outake to help stack
	trayController->waitUntilSettled();
	intakeA("out", 85);
	//Stop outtake after certain time
	pros::delay(720);
	intakeA("out", 0);
	//Back up from the unprotected zone and move tray back down
	myChassis->moveDistance(-0.6_m);
	trayController->setTarget(-tray*0.75);

}

void redBackAuton(){
	//flipout
	intakeA("out", 200);
	//Make the starting position of the tray after the flipout the new 0, should help with the weird encoder values
	trayController->tarePosition();
	//end flipout
	pros::delay(1000);
	//start intaking
	intakeA("in", 200);
	//intake the preload and the cube in front of it before the 4 stack
	myChassis->setMaxVelocity(100);
	myChassis->moveDistance(1.76_ft);
	myChassis->waitUntilSettled();
	//turn to the right
	myChassis->setMaxVelocity(55);
	myChassis->turnAngle(-90_deg);
	//Get the third cube near the zone
	myChassis->setMaxVelocity(100);
	myChassis->moveDistance(1.7_ft);
	myChassis->waitUntilSettled();
	//Turn towards zone
	myChassis->setMaxVelocity(55);
	myChassis->turnAngle(-45_deg);
	//Enter the zone
	myChassis->moveDistance(0.4_m);
	myChassis->waitUntilSettled();
	intakeA("out", 85);
	pros::delay(950);
	intakeA("out", 0);
	//Move the tray forward
	trayController->setTarget(tray*0.95);
	//Delayed outake to help stack
	trayController->waitUntilSettled();
	intakeA("out", 85);
	//Stop outtake after certain time
	pros::delay(720);
	intakeA("out", 0);
	//Back up from the unprotected zone and move tray back down
	myChassis->moveDistance(-0.6_m);
	trayController->setTarget(-tray*0.75);

}

void pranavsSpedAutonBlue(){
//Start this where the ref is during a match, but line it up directly with the 4 stack
//flipout
intakeA("out", 200);
//Make the starting position of the tray after the flipout the new 0, should help with the weird encoder values
trayController->tarePosition();
//end flipout
pros::delay(2000);
intakeA("out", 0);
//move towards the stack
myChassis->setMaxVelocity(200);
myChassis->moveDistance(1.5_ft);
myChassis->waitUntilSettled();
//Lift the tray
trayController->setTarget(tray);
trayController->waitUntilSettled();
//Slowly approach the stack and start intaking
myChassis->setMaxVelocity(45);
myChassis->moveDistance(0.7_ft);
//Delayed intake
pros::delay(500);
intakeA("in", 200);
//Stop intake quickly
pros::delay(400);
intakeA("in", 0);
//Move the tray down and turn towards the goal
trayController->setTarget(-tray*0.9);
myChassis->setMaxVelocity(70);
myChassis->turnAngle(-105_deg);
//drive towards the zone
myChassis->setMaxVelocity(200);
myChassis->moveDistance(6.3_ft);
//Move the tray forward
trayController->setTarget(tray*0.85);
//Delayed outake to help stack
trayController->waitUntilSettled();
intakeA("out", 85);
//Stop outtake after certain time
pros::delay(720);
intakeA("out", 0);
//Back up from the unprotected zone and move tray down
myChassis->moveDistance(-0.6_m);
trayController->setTarget(-tray*0.75);

}

void pranavsSpedAutonRed(){
	//Start this where the ref is during a match, but line it up directly with the 4 stack
	//flipout
	intakeA("out", 200);
	//Make the starting position of the tray after the flipout the new 0, should help with the weird encoder values
	trayController->tarePosition();
	//end flipout
	pros::delay(2000);
	intakeA("out", 0);
	//move towards the stack
	myChassis->setMaxVelocity(200);
	myChassis->moveDistance(1.5_ft);
	myChassis->waitUntilSettled();
	//Lift the tray
	trayController->setTarget(tray);
	trayController->waitUntilSettled();
	//Slowly approach the stack and start intaking
	myChassis->setMaxVelocity(45);
	myChassis->moveDistance(0.7_ft);
	//Delayed intake
	pros::delay(500);
	intakeA("in", 200);
	//Stop intake quickly
	pros::delay(400);
	intakeA("in", 0);
	//Move the tray down and turn towards the goal
	trayController->setTarget(-tray*0.9);
	myChassis->setMaxVelocity(70);
	myChassis->turnAngle(105_deg);
	//drive towards the zone
	myChassis->setMaxVelocity(200);
	myChassis->moveDistance(6.3_ft);
	//Move the tray forward
	trayController->setTarget(tray*0.85);
	//Delayed outake to help stack
	trayController->waitUntilSettled();
	intakeA("out", 85);
	//Stop outtake after certain time
	pros::delay(720);
	intakeA("out", 0);
	//Back up from the unprotected zone and move tray down
	myChassis->moveDistance(-0.6_m);
	trayController->setTarget(-tray*0.75);
}

void progSkills(){
	//flipout
	intakeA("out", 200);
	//Make the starting position of the tray after the flipout the new 0, should help with the weird encoder values
	trayController->tarePosition();
	//end flipout
	pros::delay(2000);
	intakeA("out", 0);
	//Start intaking
	intakeA("in", 200);
	//intake the preload and the cube in front of it before the 4 stack and go on to take the 4 on the other side
	myChassis->setMaxVelocity(150);
	myChassis->moveDistance(2.4412_m);
	myChassis->waitUntilSettled();
	//Back up after taking in all the cubes
	myChassis->setMaxVelocity(45);
	myChassis->moveDistance(-0.335_m);
	myChassis->waitUntilSettled();
	//Turn towards the zone (red unprotected)
  myChassis->turnAngle(-45_deg);
	//Enter the zone
	myChassis->moveDistance(0.4_m);
	myChassis->waitUntilSettled();
	//Move the tray forward
	trayController->setTarget(tray*0.95);
	//Delayed outake to help stack
	trayController->waitUntilSettled();
	intakeA("out", 85);
	//Stop outtake after certain time
	pros::delay(720);
	intakeA("out", 0);
	//Back up from the unprotected zone and move tray back down
	myChassis->moveDistance(-0.6_m);
	trayController->setTarget(-tray*0.75);
}

void intakeA(std::string dir, double velocity){
	if(dir.compare("in") == 0){
		intakeL.move_velocity(velocity);
		intakeR.move_velocity(-velocity);
	}
	else{
		intakeL.move_velocity(-velocity);
		intakeR.move_velocity(velocity);
	}
}




/**
 * Runs the operator control code. This function will be started in its own task
 * with the default priority and stack size whenever the robot is enabled via
 * the Field Management System or the VEX Competition Switch in the operator
 * control mode.
 *
 * If no competition control is connected, this function will run immediately
 * following initialize().
 *
 * If the robot is disabled or communications is lost, the
 * operator control task will be stopped. Re-enabling the robot will restart the
 * task, not resume it from where it left off.
 */

 float kP = 1;
 float kI = 0;
 float kD = 0;
 //MIGHT USE FOR THE STACK METHOD, WILL BE HELPFUL WITH PID
 auto specialTrayController = okapi::AsyncPosControllerBuilder()
 .withMotor(-1)
 .withGains({kP, kI, kD})
 .build();
 void stackingMacro(void*){
 	while(true){


 			pros::delay(20);

 		}

 }
 void trayAdjustMethod(void*){
	 while(true){

		pros::delay(20);
	 }
 }
 void towerMacroMethod(void*){
	 while(true){



		pros::delay(20);
	 }

 }
 void driveToggleMethod(void*){

	 while(true){

		pros::delay(20);
	 }

 }

ADIButton testButton('B');
void opcontrol() {
	twoBar->tarePosition();
//	pros::Task trayAdjustTask(trayAdjustMethod,(void*)"PROS" ,TASK_PRIORITY_DEFAULT, TASK_STACK_DEPTH_DEFAULT, "Tray Adjust");
//	pros::Task towerMacroTask(towerMacroMethod, (void*)"PROS", TASK_PRIORITY_DEFAULT, TASK_STACK_DEPTH_DEFAULT, "Tower Macro");
//	pros::Task driveToggleTask(driveToggleMethod,(void*)"PROS", TASK_PRIORITY_DEFAULT, TASK_STACK_DEPTH_DEFAULT, "Drive Toggle");
//	pros::Task stackMacroTask(stackingMacro, (void*)"PROS", TASK_PRIORITY_DEFAULT, TASK_STACK_DEPTH_DEFAULT, "Stacking Macro");
	while (true) {
	/*	pros::lcd::print(0, "%d %d %d", (pros::lcd::read_buttons() & LCD_BTN_LEFT) >> 2,
		                 (pros::lcd::read_buttons() & LCD_BTN_CENTER) >> 1,
		                 (pros::lcd::read_buttons() & LCD_BTN_RIGHT) >> 0);
										 */
		//SLOW DRIVE TOGGLE
		pros::lcd::clear_line(1);
		pros::lcd::clear_line(2);
		pros::lcd::clear_line(3);
		std::string output = "Actuator Position: "+std::to_string(actuatorM.get_position());
		std::string output2 = "Twobar Position: "+std::to_string(twobarM.get_position());
		std::string limitSwitch = "Switch Condition: "+std::to_string(testButton.isPressed());
		std::string tempCheck = "Actuator Temperature: "+std::to_string(actuatorM.get_temperature());
		pros::lcd::set_text(1, output);
		pros::lcd::set_text(2, output2);
		pros::lcd::set_text(3, limitSwitch);
		pros::lcd::set_text(4, tempCheck);		//SLOW DRIVE TOGGLE
		if(driveToggle.isPressed()){
					if(toggle == true)
							toggle = false;
					else
							toggle = true;
		}
		//TWO BAR MACRO
		if( towerMacro.isPressed() ){
					double distance = abs(medTowerPosition - twobarM.get_position());
					twoBar->setTarget(distance);
				}

		//TRAY RETURN TO ZERO MACRO
		if( trayAdjuster.isPressed() ){
				 double distanceToTravel = 0 - actuatorM.get_position();
				 trayController->setTarget(-distanceToTravel);
			 }

			 //A STACKING MACRO
			 if(stackMacro.isPressed()){
	  		//	actuatorM.move_absolute(-tray, 200);
				trayController->setTarget(tray);
				trayController->waitUntilSettled();
	  			//Delayed outake to help stack
	  			intakeA("out", 85);
	  			//Stop outtake after certain time
	  			pros::delay(720);
	  			intakeA("out", 0);
	  			//Back up from the zone and move tray back down
	  			myChassis->moveDistance(-0.5_m);
	  			trayController->setTarget(-tray);
	  		}



//REGULAR SPEED DRIVE
		if(toggle == false){
		motorFR.move_velocity(( (contrl.get_analog(ANALOG_RIGHT_X)/5) - contrl.get_analog(ANALOG_LEFT_Y)*2 )*2);
		motorFL.move_velocity(( (contrl.get_analog(ANALOG_RIGHT_X)/5) + contrl.get_analog(ANALOG_LEFT_Y)*2 )*2);
		motorBR.move_velocity(( (contrl.get_analog(ANALOG_RIGHT_X)/5) - contrl.get_analog(ANALOG_LEFT_Y)*2 )*2);
		motorBL.move_velocity(( (contrl.get_analog(ANALOG_RIGHT_X)/5) + contrl.get_analog(ANALOG_LEFT_Y)*2 )*2);
	}
//TOGGLED SLOW DRIVE
		else{
			motorFR.move_velocity((contrl.get_analog(ANALOG_RIGHT_X)-contrl.get_analog(ANALOG_LEFT_Y))/2);
			motorFL.move_velocity((contrl.get_analog(ANALOG_RIGHT_X)+contrl.get_analog(ANALOG_LEFT_Y))/2);
			motorBR.move_velocity((contrl.get_analog(ANALOG_RIGHT_X)-contrl.get_analog(ANALOG_LEFT_Y))/2);
			motorBL.move_velocity((contrl.get_analog(ANALOG_RIGHT_X)+contrl.get_analog(ANALOG_LEFT_Y))/2);
		}



		//TRAY TILTER CONTROLS
		if(abs(actuatorM.get_position()) < abs(tray*0.60)){
				if(contrl.get_digital(DIGITAL_X))
						actuatorM.move_velocity(-200);
				else if(contrl.get_digital(DIGITAL_A))
						actuatorM.move_velocity(200);
				else{
					actuatorM.set_brake_mode(MOTOR_BRAKE_HOLD);
					actuatorM.move_velocity(0);
				}
			}
		else{
			if(contrl.get_digital(DIGITAL_X))
					actuatorM.move_velocity(-100);
			else if(contrl.get_digital(DIGITAL_A))
					actuatorM.move_velocity(200);
			else{
				actuatorM.set_brake_mode(MOTOR_BRAKE_HOLD);
				actuatorM.move_velocity(0);
			}
		}


//TWOBAR CONTROLS
		if(contrl.get_digital(DIGITAL_R2)){
				twobarM.move_velocity(200);
		}
		else if(contrl.get_digital(DIGITAL_L2)){
				twobarM.move_velocity(-200);
		}
		else{
			twobarM.set_brake_mode(MOTOR_BRAKE_HOLD);
			twobarM.move(0);
		}
//INTAKE CONTROLS
if(contrl.get_digital(DIGITAL_R1)){
if(contrl.get_digital(DIGITAL_LEFT)){
intakeL.move_velocity(200);
}
else if(contrl.get_digital(DIGITAL_RIGHT)){
  intakeR.move_velocity(-200);
}
else{
intakeL.move_velocity(200);
intakeR.move_velocity(-200);
}
}
else if(contrl.get_digital(DIGITAL_L1)){
 if(contrl.get_digital(DIGITAL_RIGHT)){
 intakeR.move_velocity(200);
}
 else if(contrl.get_digital(DIGITAL_LEFT)){
   intakeL.move_velocity(-200);
 }
 else{
  intakeL.move_velocity(-200);
 intakeR.move_velocity(200);

 }

}

else{
	intakeL.set_brake_mode(MOTOR_BRAKE_HOLD);
	intakeR.set_brake_mode(MOTOR_BRAKE_HOLD);
	intakeL.move_velocity(0);
 intakeR.move_velocity(0);
}
		pros::delay(20);
	}//End of control loop


}
//End of Op Control
