#include "main.h"
using namespace okapi;
/**
 * A callback function for LLEMU's center button.
 *
 * When this callback is fired, it will toggle line 2 of the LCD text between
 * "I was pressed!" and nothing.
 */
void on_center_button() {
	static bool pressed = false;
	pressed = !pressed;
	if (pressed) {
		pros::lcd::set_text(2, "I was pressed!");
	} else {
		pros::lcd::clear_line(2);
	}
}
ControllerButton trayAdjuster(ControllerDigital::up, false);
ControllerButton towerMacro(ControllerDigital::down, false);
/**
 * Runs initialization code. This occurs as soon as the program is started.
 *
 * All other competition modes are blocked by initialize; it is recommended
 * to keep execution time for this mode under a few seconds.
 */
void initialize() {
	pros::lcd::initialize();
	pros::lcd::set_text(1, "Hello PROS User!");
	pros::lcd::register_btn1_cb(on_center_button);

	pros::lcd::clear_line(1);
	pros::lcd::set_text(1, "No auton currently selected.");


}

/**
 * Runs while the robot is in the disabled state of Field Management System or
 * the VEX Competition Switch, following either autonomous or opcontrol. When
 * the robot is enabled, this task will exit.
 */
void disabled() {}

/**
 * Runs after initialize(), and before autonomous when connected to the Field
 * Management System or the VEX Competition Switch. This is intended for
 * competition-specific initialization routines, such as an autonomous selector
 * on the LCD.
 *
 * This task will exit when the robot is enabled and autonomous or opcontrol
 * starts.
 */
 //lv_obj_t *
 /*drawRectangle( int x, int y, int width, int length, lv_color_t color ) {
   lv_obj_t * obj1 = lv_obj_create(lv_scr_act(), NULL);

   lv_style_t *style1 = (lv_style_t *)malloc( sizeof( lv_style_t ));
   lv_style_copy(style1, &lv_style_plain_color);    Copy a built-in style to initialize the new style
   style1->body.empty = 1;
   style1->body.border.color = color;
   style1->body.border.width = 1;
   style1->body.border.part = LV_BORDER_FULL;

   lv_obj_set_style(obj1, style1);
   lv_obj_set_pos(obj1, x, y);
   lv_obj_set_size(obj1, width, height);

   return obj1;
 }
 */




void competition_initialize() {

}



/**
 * Runs the user autonomous code. This function will be started in its own task
 * with the default priority and stack size whenever the robot is enabled via
 * the Field Management System or the VEX Competition Switch in the autonomous
 * mode. Alternatively, this function may be called in initialize or opcontrol
 * for non-competition testing purposes.
 *
 * If the robot is disabled or communications is lost, the autonomous task
 * will be stopped. Re-enabling the robot will restart the task, not re-start it
 * from where it left off.
 */
 auto myChassis = okapi::ChassisControllerBuilder()
 .withMotors({14,12},{-19,-21})
 .withDimensions(AbstractMotor::gearset::green, {{4.2_in, 10_in}, imev5GreenTPR})
 //.withGains({0.3,0.1,0.05},{0,0,0})
 .build();

 auto twoBar = okapi::AsyncPosControllerBuilder()
 .withMotor(16)
 .build();

 auto trayController = okapi::AsyncPosControllerBuilder()
 .withMotor(-1)
 .build();


void autonomous() {
		blueFrontAuton();
	//blueBackAuton();
	//redFrontAuton();
	//redBackAuton();
	//pranavsSpedAutonBlue();
}

void blueFrontAuton(){
	//Push preload towards row of 4
	//flipout
	intakeA("out", 200);
	//Make the starting position of the tray after the flipout the new 0, should help with the weird encoder values
	trayController->tarePosition();
	//end flipout
	pros::delay(2000);
	//start intaking
	intakeA("in", 200);

	//intake the stack
	myChassis->setMaxVelocity(55);
	myChassis->moveDistance(1.2206_m);
	myChassis->waitUntilSettled();
	//Slow outake to adjust for extra intake
	intakeA("out", 70);
	pros::delay(550);
	intakeA("out", 0);
	//Drive back
	myChassis->setMaxVelocity(200);
	myChassis->moveDistance(-0.8206_m);
	myChassis->waitUntilSettled();
	//Turn towards the unprotected zone
	myChassis->setMaxVelocity(70);
	//Turn left
	myChassis->turnAngle(-115_deg);
	//Enter unprotected zone
	myChassis->setMaxVelocity(200);
	myChassis->moveDistance(0.3875_m);
	myChassis->waitUntilSettled();
	//Move the tray forward
	trayController->setTarget(tray*0.95);
	//Delayed outake to help stack
	trayController->waitUntilSettled();
	intakeA("out", 85);
	//Stop outtake after certain time
	pros::delay(720);
	intakeA("out", 0);
	//Back up from the unprotected zone and move tray back down
	myChassis->moveDistance(-0.6_m);
	trayController->setTarget(-tray*0.75);
}

void redFrontAuton(){
	//Push preload towards row of 4
	//flipout
	intakeA("out", 200);
	//Make the starting position of the tray after the flipout the new 0, should help with the weird encoder values
	trayController->tarePosition();
	//end flipout
	pros::delay(2000);
	//start intaking
	intakeA("in", 200);

	//intake the stack
	myChassis->setMaxVelocity(55);
	myChassis->moveDistance(1.2206_m);
	myChassis->waitUntilSettled();
	//Slow outake to adjust for extra intake
	intakeA("out", 70);
	pros::delay(550);
	intakeA("out", 0);
	//Drive back
	myChassis->setMaxVelocity(200);
	myChassis->moveDistance(-0.8206_m);
	myChassis->waitUntilSettled();
	//Turn towards the unprotected zone
	myChassis->setMaxVelocity(70);
	//Turn left
	myChassis->turnAngle(115_deg);
	//Enter unprotected zone
	myChassis->setMaxVelocity(200);
	myChassis->moveDistance(0.3875_m);
	myChassis->waitUntilSettled();
	//Move the tray forward
	trayController->setTarget(tray*0.95);
	//Delayed outake to help stack
	trayController->waitUntilSettled();
	intakeA("out", 85);
	//Stop outtake after certain time
	pros::delay(720);
	intakeA("out", 0);
	//Back up from the unprotected zone and move tray back down
	myChassis->moveDistance(-0.6_m);
	trayController->setTarget(-tray*0.75);
}

void blueBackAuton(){
	//flipout
	intakeA("out", 200);
	//Make the starting position of the tray after the flipout the new 0, should help with the weird encoder values
	trayController->tarePosition();
	//end flipout
	pros::delay(2000);
	//start intaking
	intakeA("in", 200);
	//intake the preload and the cube in front of it before the 4 stack
	myChassis->setMaxVelocity(150);
	myChassis->moveDistance(1.75_ft);
	myChassis->waitUntilSettled();
	//turn to the right
	myChassis->setMaxVelocity(70);
	myChassis->turnAngle(90_deg);
	//Get the third cube near the zone
	myChassis->setMaxVelocity(125);
	myChassis->moveDistance(2.5_ft);
	myChassis->waitUntilSettled();
	//Back up a little to position for stacking
	myChassis->setMaxVelocity(75);
	myChassis->moveDistance(-1.2_ft);
	myChassis->waitUntilSettled();
	//Turn towards zone
	myChassis->setMaxVelocity(70);
	myChassis->turnAngle(45_deg);
	//Enter the zone
	myChassis->moveDistance(0.4_m);
	myChassis->waitUntilSettled();
	//Move the tray forward
	trayController->setTarget(tray*0.95);
	//Delayed outake to help stack
	trayController->waitUntilSettled();
	intakeA("out", 85);
	//Stop outtake after certain time
	pros::delay(720);
	intakeA("out", 0);
	//Back up from the unprotected zone and move tray back down
	myChassis->moveDistance(-0.6_m);
	trayController->setTarget(-tray*0.75);

}

void redBackAuton(){
	//flipout
	intakeA("out", 200);
	//Make the starting position of the tray after the flipout the new 0, should help with the weird encoder values
	trayController->tarePosition();
	//end flipout
	pros::delay(2000);
	//start intaking
	intakeA("in", 200);
	//intake the preload and the cube in front of it before the 4 stack
	myChassis->setMaxVelocity(150);
	myChassis->moveDistance(1.75_ft);
	myChassis->waitUntilSettled();
	//turn to the right
	myChassis->setMaxVelocity(70);
	myChassis->turnAngle(-90_deg);
	//Get the third cube near the zone
	myChassis->setMaxVelocity(125);
	myChassis->moveDistance(2.5_ft);
	myChassis->waitUntilSettled();
	//Back up a little to position for stacking
	myChassis->setMaxVelocity(75);
	myChassis->moveDistance(-1.2_ft);
	myChassis->waitUntilSettled();
	//Turn towards zone
	myChassis->setMaxVelocity(70);
	myChassis->turnAngle(-45_deg);
	//Enter the zone
	myChassis->moveDistance(0.4_m);
	myChassis->waitUntilSettled();
	//Move the tray forward
	trayController->setTarget(tray*0.95);
	//Delayed outake to help stack
	trayController->waitUntilSettled();
	intakeA("out", 85);
	//Stop outtake after certain time
	pros::delay(720);
	intakeA("out", 0);
	//Back up from the unprotected zone and move tray back down
	myChassis->moveDistance(-0.6_m);
	trayController->setTarget(-tray*0.75);

}

void pranavsSpedAutonBlue(){
//Start this where the ref is during a match, but line it up directly with the 4 stack
//flipout
intakeA("out", 200);
//Make the starting position of the tray after the flipout the new 0, should help with the weird encoder values
trayController->tarePosition();
//end flipout
pros::delay(2000);
intakeA("out", 0);
//move towards the stack
myChassis->setMaxVelocity(200);
myChassis->moveDistance(1.5_ft);
myChassis->waitUntilSettled();
//Lift the tray
trayController->setTarget(tray);
trayController->waitUntilSettled();
//Slowly approach the stack and start intaking
myChassis->setMaxVelocity(45);
myChassis->moveDistance(0.7_ft);
//Delayed intake
pros::delay(500);
intakeA("in", 200);
//Stop intake quickly
pros::delay(400);
intakeA("in", 0);
//Move the tray down and turn towards the goal
trayController->setTarget(-tray*0.9);
myChassis->setMaxVelocity(70);
myChassis->turnAngle(-105_deg);
//drive towards the zone
myChassis->setMaxVelocity(200);
myChassis->moveDistance(6.3_ft);
//Move the tray forward
trayController->setTarget(tray*0.85);
//Delayed outake to help stack
trayController->waitUntilSettled();
intakeA("out", 85);
//Stop outtake after certain time
pros::delay(720);
intakeA("out", 0);
//Back up from the unprotected zone and move tray down
myChassis->moveDistance(-0.6_m);
trayController->setTarget(-tray*0.75);

}

void pranavsSpedAutonRed(){
	//Start this where the ref is during a match, but line it up directly with the 4 stack
	//flipout
	intakeA("out", 200);
	//Make the starting position of the tray after the flipout the new 0, should help with the weird encoder values
	trayController->tarePosition();
	//end flipout
	pros::delay(2000);
	intakeA("out", 0);
	//move towards the stack
	myChassis->setMaxVelocity(200);
	myChassis->moveDistance(1.5_ft);
	myChassis->waitUntilSettled();
	//Lift the tray
	trayController->setTarget(tray);
	trayController->waitUntilSettled();
	//Slowly approach the stack and start intaking
	myChassis->setMaxVelocity(45);
	myChassis->moveDistance(0.7_ft);
	//Delayed intake
	pros::delay(500);
	intakeA("in", 200);
	//Stop intake quickly
	pros::delay(400);
	intakeA("in", 0);
	//Move the tray down and turn towards the goal
	trayController->setTarget(-tray*0.9);
	myChassis->setMaxVelocity(70);
	myChassis->turnAngle(105_deg);
	//drive towards the zone
	myChassis->setMaxVelocity(200);
	myChassis->moveDistance(6.3_ft);
	//Move the tray forward
	trayController->setTarget(tray*0.85);
	//Delayed outake to help stack
	trayController->waitUntilSettled();
	intakeA("out", 85);
	//Stop outtake after certain time
	pros::delay(720);
	intakeA("out", 0);
	//Back up from the unprotected zone and move tray down
	myChassis->moveDistance(-0.6_m);
	trayController->setTarget(-tray*0.75);
}

void intakeA(std::string dir, double velocity){
	if(dir.compare("in") == 0){
		intakeL.move_velocity(velocity);
		intakeR.move_velocity(-velocity);
	}
	else{
		intakeL.move_velocity(-velocity);
		intakeR.move_velocity(velocity);
	}
}

/**
 * Runs the operator control code. This function will be started in its own task
 * with the default priority and stack size whenever the robot is enabled via
 * the Field Management System or the VEX Competition Switch in the operator
 * control mode.
 *
 * If no competition control is connected, this function will run immediately
 * following initialize().
 *
 * If the robot is disabled or communications is lost, the
 * operator control task will be stopped. Re-enabling the robot will restart the
 * task, not resume it from where it left off.
 */

void opcontrol() {
	bool toggle = false;
	twoBar->tarePosition();
	while (true) {
	/*	pros::lcd::print(0, "%d %d %d", (pros::lcd::read_buttons() & LCD_BTN_LEFT) >> 2,
		                 (pros::lcd::read_buttons() & LCD_BTN_CENTER) >> 1,
		                 (pros::lcd::read_buttons() & LCD_BTN_RIGHT) >> 0);
										 */
		//SLOW DRIVE TOGGLE
		pros::lcd::clear_line(1);
		pros::lcd::clear_line(2);
		std::string output = "Actuator Position: "+std::to_string(actuatorM.get_position());
		std::string output2 = "Twobar Position: "+std::to_string(twobarM.get_position());
		pros::lcd::set_text(1, output);
		pros::lcd::set_text(2, output2);

		if( trayAdjuster.isPressed() ){
			double distance = actuatorM.get_position();
			actuatorM.move_relative(-distance, 200);
		}

		if( contrl.get_digital_new_press(DIGITAL_Y) ){
					if(toggle == true)
							toggle = false;
					else
							toggle = true;

		}
		if( towerMacro.isPressed() ){
					double distance = medTowerPosition - actuatorM.get_position();
					twoBar->setTarget(distance);
					twoBar->waitUntilSettled();
				}

//REGULAR SPEED DRIVE
		if(toggle == false){
		motorFR.move_velocity(( (contrl.get_analog(ANALOG_RIGHT_X)/5) - contrl.get_analog(ANALOG_LEFT_Y)*2 )*2);
		motorFL.move_velocity(( (contrl.get_analog(ANALOG_RIGHT_X)/5) + contrl.get_analog(ANALOG_LEFT_Y)*2 )*2);
		motorBR.move_velocity(( (contrl.get_analog(ANALOG_RIGHT_X)/5) - contrl.get_analog(ANALOG_LEFT_Y)*2 )*2);
		motorBL.move_velocity(( (contrl.get_analog(ANALOG_RIGHT_X)/5) + contrl.get_analog(ANALOG_LEFT_Y)*2 )*2);
	}
//TOGGLED SLOW DRIVE
		else{
			motorFR.move_velocity((contrl.get_analog(ANALOG_RIGHT_X)-contrl.get_analog(ANALOG_LEFT_Y))/2);
			motorFL.move_velocity((contrl.get_analog(ANALOG_RIGHT_X)+contrl.get_analog(ANALOG_LEFT_Y))/2);
			motorBR.move_velocity((contrl.get_analog(ANALOG_RIGHT_X)-contrl.get_analog(ANALOG_LEFT_Y))/2);
			motorBL.move_velocity((contrl.get_analog(ANALOG_RIGHT_X)+contrl.get_analog(ANALOG_LEFT_Y))/2);
		}
		if(abs(actuatorM.get_position()) < abs(tray*0.60)){
				if(contrl.get_digital(DIGITAL_X))
						actuatorM.move_velocity(-200);
				else if(contrl.get_digital(DIGITAL_A))
						actuatorM.move_velocity(200);
				else{
					actuatorM.set_brake_mode(MOTOR_BRAKE_HOLD);
					actuatorM.move_velocity(0);
				}
			}
		else{
			if(contrl.get_digital(DIGITAL_X))
					actuatorM.move_velocity(-100);
			else if(contrl.get_digital(DIGITAL_A))
					actuatorM.move_velocity(200);
			else{
				actuatorM.set_brake_mode(MOTOR_BRAKE_HOLD);
				actuatorM.move_velocity(0);
			}
		}

/*
			if(contrl.get_digital(DIGITAL_X))
					actuatorM.move_velocity(-100);
			else if(contrl.get_digital(DIGITAL_A))
					actuatorM.move_voltage(100);
			else{
					actuatorM.set_brake_mode(MOTOR_BRAKE_HOLD);
					actuatorM.move_velocity(0);
					}
					*/


		if(contrl.get_digital(DIGITAL_R2)){
				twobarM.move_velocity(200);
		}
		else if(contrl.get_digital(DIGITAL_L2)){
				twobarM.move_velocity(-200);
		}
		else{
			twobarM.set_brake_mode(MOTOR_BRAKE_HOLD);
			twobarM.move(0);
		}
//INTAKE CONTROLS
if(contrl.get_digital(DIGITAL_R1)){
if(contrl.get_digital(DIGITAL_LEFT)){
intakeL.move_velocity(200);
}
else if(contrl.get_digital(DIGITAL_RIGHT)){
  intakeR.move_velocity(-200);
}
else{
intakeL.move_velocity(200);
intakeR.move_velocity(-200);
}
}
else if(contrl.get_digital(DIGITAL_L1)){
 if(contrl.get_digital(DIGITAL_RIGHT)){
 intakeR.move_velocity(200);
}
 else if(contrl.get_digital(DIGITAL_LEFT)){
   intakeL.move_velocity(-200);
 }
 else{
  intakeL.move_velocity(-200);
 intakeR.move_velocity(200);
 }

}

else{
	intakeL.set_brake_mode(MOTOR_BRAKE_HOLD);
	intakeR.set_brake_mode(MOTOR_BRAKE_HOLD);
	intakeL.move_velocity(0);
 intakeR.move_velocity(0);
}
//PREVIOUS ACTUATOR METHOD
/*if(contrl.get_digital(DIGITAL_X)){

  if(abs((int)actuatorM.get_position()) > tray*0.45){
  actuatorM.move_velocity(-100);
  }
  else{
  actuatorM.move_velocity(-200);
  }

}
else if(contrl.get_digital(DIGITAL_UP)) {

   if(abs((int)actuatorM.get_position()) > tray*0.45){
		 actuatorM.move_velocity(100);
  }
  else{
  	 actuatorM.move_velocity(200);
  }
  }

else{
	actuatorM.set_brake_mode(MOTOR_BRAKE_HOLD);
  actuatorM.move_velocity(0);
}
*/
//TWOBAR CONTROLS
	if(contrl.get_digital_new_press(DIGITAL_B) > 0){
			double position = abs(twobarM.get_position() - height);
			if(twobarM.get_position() > constant){
				twobarM.move_relative(position, -200);
			}
			if(twobarM.get_position() < constant){
				twobarM.move_relative(position, 200);
			}
	}

		pros::delay(20);
	}
}
